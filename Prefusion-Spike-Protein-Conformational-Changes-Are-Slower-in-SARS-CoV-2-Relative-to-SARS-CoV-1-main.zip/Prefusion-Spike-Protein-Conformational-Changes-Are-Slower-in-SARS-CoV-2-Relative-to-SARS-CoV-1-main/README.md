# Prefusion-Spike-Protein-Conformational-Changes-Are-Slower-in-SARS-CoV-2-Relative-to-SARS-CoV-1
Script and Macros Used for Analysis of MD Trajectories of Spike Proteins Studied in Article: **Prefusion Spike Protein Conformational Changes Are Slower in SARS-CoV-2 Relative to SARS-CoV-1**
